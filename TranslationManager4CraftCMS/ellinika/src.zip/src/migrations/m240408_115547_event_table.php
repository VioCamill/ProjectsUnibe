<?php

namespace pse\craftellinika\migrations;

use Craft;
use craft\db\Migration;

/**
 * m240408_115547_event_table migration.
 *
 * This migration class creates or drops the 'ellinika' table in Craft CMS database.
 * The table is used for storing entries related to translations.
 * 
 * @author      Daniele De Jeso
 * @version     v1.0
 */
class m240408_115547_event_table extends Migration
{
    /**
     * Creates the 'ellinika' table.
     * 
     * This method creates the database table 'ellinika' with the specified schema:
     * - id: Primary key of the table.
     * - entry_id: Integer field representing the related entry ID.
     * - text: String field for storing the text without translation.
     * - url: String field for storing the URL.
     * 
     * @return bool Whether the migration was successful.
     */
    public function safeUp(): bool
    {
        // Creating table 'ellinika'
        $this->createTable('{{%ellinika_db}}', [
            'id' => $this->primaryKey(),
            'entry_id' => $this->integer()->notNull(),
            'language_id' => $this->integer()->notNull(),
            'latest_Update' => $this->string()->notNull(),
            'changed'=> $this->boolean()->notNull(),
        ]);

        return true;
    }

    /**
     * Drops the 'ellinika' table.
     * 
     * This method drops the 'ellinika' table from the database.
     * 
     * @return bool Whether the migration was successful.
     */
    public function safeDown(): bool
    {
        // Deleting table 'ellinika'
        $this->dropTable('{{%ellinika_db}}');

        return true;
    }
}
