<?php

namespace pse\craftellinika\controllers;

use Craft;
use craft\elements\Entry;
use DateTime;
use DateTimeZone;
use yii\db\Exception;

/**
 * EntryHandler checks an entry on multilingual websites
 * for inconsistencies in the updates
 *
 * @author Kevin Lautenschlager, Viola Meier
 * @version  v1.0
 */

class EntryHandler
{

    private Entry $changedEntry;
    private int $changedSiteId;
    private DateTime $changedUpdate;
    private array $translatedEntries = [];
    private array $translatedSiteIds = [];
    private array $translatedUpdates = [];

    /**
     * Constructs an EntryHandler object
     * @param Entry $entry which triggered EVENT_AFTER_SAFE
     *
     * @throws \Exception
     */
    public function __construct(Entry $entry)
    {
        //assert($entry->id != null && !$entry->getIsDraft() && !$entry->trashed);
        $this->changedEntry = $entry;
    }

    /**
     * Processes the entry, checks translations, and sets flash message
     * @throws Exception
     */
    public function processEntry(): void
    {
        Craft::info("Start Entry Handler Class with Entry {$this->changedEntry->title}",'custom-module');
        $this->setVariables($this->changedEntry);
        Craft::info("We're back in processEntry method", 'custom-module');
        UpdateController::insertUpdateData($this->changedEntry, $this->changedUpdate->format('Y-m-d H:i:s'));
        $inTable = UpdateController::isInTable($this->changedEntry->id,$this->changedEntry->siteId);
        Craft::info("Entry should be in Update db now {$inTable}", 'custom-module');
        $this->getTranslatedInformation($this->changedEntry);
        EllinikaController::insertEntryData($this->changedEntry,
                $this->changedUpdate->format('Y-m-d H:i:s'), true);
        $this -> setDBTable();

    }

    private function setVariables(Entry $entry):void
    {
        Craft::info("Inside setVariables",'custom-module');
        $this->changedSiteId = $entry->siteId;
        $this->changedUpdate = new DateTime('now',
            new DateTimeZone('Europe/Zurich'));
        Craft::info("The Entry has last_Update {$this->changedUpdate->format('Y-m-d H:i:s')}",'custom-module');
    }

    /**
     * stores entryIdy, titles from translated versions
     * @param Entry $entry extract all related information
     * @return void
     * @throws Exception
     */
    private function getTranslatedInformation(Entry $entry): void
    {   Craft::info("We're in getTranslatedInformation method now", 'custom-module');
        $supportedSites = $entry->getSupportedSites();
        $this->translatedSiteIds = array_column($supportedSites, 'siteId');
        $siteIds = array_diff($this->translatedSiteIds, [$this->changedSiteId]);
        foreach ($siteIds as $siteId) {
            $translatedEntry = Entry::find()
                ->id($entry->id)
                ->siteId($siteId)
                ->one();
            if ($translatedEntry) {
                $this->translatedEntries[] = $translatedEntry;
                /**
                 * only for tracking purposes
                 */
                $translatedEntriesString = "";
                foreach ($this->translatedEntries as $entry) {
                    $translatedEntriesString = "ID: {$entry->id}, Title: {$entry->title}, SiteId: {$entry->id}\n";
                }
                Craft::info("Display all related information's {$translatedEntriesString}", 'custom-module');
            }
        }
    }

    /**
     * @throws Exception
     */
    private function setDBTable():void {
        if(count($this -> translatedEntries) != 0){
            foreach ($this -> translatedEntries as $translatedEntry) {
                $inUpdateTable = UpdateController::isInTable($translatedEntry -> id, $translatedEntry->siteId);
                $latestUpdate = $translatedEntry->dateCreated->setTimezone(new DateTimeZone('Europe/Zurich'))->format('Y-m-d H:i:s');
                if($inUpdateTable){
                    $latestUpdate = UpdateController::getLastUpdate($translatedEntry->id, $translatedEntry->siteId);
                }
                UpdateController::insertUpdateData($translatedEntry, $latestUpdate);
                $inTable = EllinikaController::isInTable($translatedEntry->id, $translatedEntry->siteId);
                $this->getTimeDiff($this->changedUpdate, $latestUpdate);
                if(!$inTable){
                    //Craft::info("Still have to check time diff here", 'custom-module');
                    EllinikaController::insertEntryData($translatedEntry,
                        $latestUpdate, false);
                } else {
                    EllinikaController::insertEntryData($translatedEntry,
                        $latestUpdate, true);
                }
            }
        }
    }

    /**
     * @throws \Exception
     */
    private function getTimeDiff(DateTime $changedUpdate, string $latestUpdate)
    {

    }
}
