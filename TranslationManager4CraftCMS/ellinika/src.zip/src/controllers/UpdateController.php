<?php

namespace pse\craftellinika\controllers;

use Craft;
use craft\db\Query;
use craft\elements\Entry;
use DateTime;
use yii\db\Exception;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

class UpdateController extends Controller
{
    public static function insertUpdateData(Entry $entry, String $lastUpdate): void
    {
        Craft::info(" {$entry ->title} is Inserted to Update db", 'custom-module');
        $db = Craft::$app->getDb();
        $inTable = self::isInTable($entry->id, $entry->siteId);
        Craft::info("First break in insertUpdateDB should not be in table {$inTable}",'custom-module');
        if($inTable){
            $db->createCommand()->delete('{{%update_db}}', [
                'entry_id' => $entry->id,
                'language_id' => $entry->siteId
            ])->execute();

        }
        $db->createCommand() ->insert('{{%update_db}}', [
            'entry_id' => $entry->id,
            'language_id' => $entry->siteId,
            'last_Update' => $lastUpdate
        ])->execute();
    }

    public static function isInTable(int $entryId, int $siteId): bool
    {
        $exists = (new Query())
            ->from('{{%update_db}}')
            ->where([
                'entry_id' => $entryId,
                'language_id' => $siteId,
            ])
            ->exists();
        return $exists;
    }



        /**
     * @throws Exception
     */
    public static function getLastUpdate(int $entryId, int $siteId): ?string
    {
        $lastUpdate = (new Query())
            ->select(['last_Update'])
            ->from('{{%update_db}}')
            ->where([
                'entry_id' => $entryId,
                'language_id' => $siteId,
            ])
            ->scalar();
        return $lastUpdate;
    }


    public function actionDeleteEntry($id, $siteId)
    {
        $affectedRows = Craft::$app->getDb()->createCommand()
            ->delete('{{%update_db}}', ['id' => $id], ['siteId' => $siteId])
            ->execute();

        if ($affectedRows) {
            $entries = Craft::$app->getDb()->createCommand('SELECT * FROM {{%update_db}}')->queryAll();
            $columns = !empty($entries) ? array_keys($entries[0]) : [];
            return $this->renderTemplate('ellinika/index', ['entries' => $entries, 'columns' => $columns]);
        } else {
            throw new NotFoundHttpException('The requested entry does not exist or could not be deleted.');
        }
    }

}