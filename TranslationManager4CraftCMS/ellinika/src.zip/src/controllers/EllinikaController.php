<?php

namespace pse\craftellinika\controllers;

use Craft;
use craft\db\Query;
use craft\elements\Entry;
use craft\web\Controller;
use craft\helpers\Db;
use pse\craftellinika\models\Ellinika;
use Stringy\Stringy;
use yii\db\Exception;
use yii\web\NotFoundHttpException;

/**
 * Handles data manipulation and interactions for the Ellinika plugin.
 * This controller manages database operations such as retrieving, inserting, and deleting entries.
 * 
 * @author Daniele De Jeso
 * @version 1.1
 */
class EllinikaController extends Controller
{

    /**
     * Inserts entry data into the plugin's database table.
     * This method is called as part of the event handling for entry saving,
     * inserting relevant data from the entry into the 'ellinika_db' table.
     *
     * @param Entry $entry The entry that has been saved.
     */
    public static function insertEntryData(Entry $entry, String $latestUpdate, bool $changed): void
    {
        $db = Craft::$app->getDb();
        $inTable = self::isInTable($entry -> id, $entry ->siteId);
        if($inTable){
            $db->createCommand()->delete('{{%ellinika_db}}', [
                'entry_id' => $entry->id,
                'language_id' => $entry->siteId
            ])->execute();

        }
        $db->createCommand()->insert('{{%ellinika_db}}', [
            'entry_id' => $entry->id,
            'language_id' => $entry->siteId,
            'latest_Update' => $latestUpdate,
            'changed'=> $changed
        ])->execute();
    }

    /**
     *  AT THE MOMENT NOT USED
     *
     * Retrieves a specific entry from the database by ID.
     *
     * @param int $id The ID of the entry to retrieve.
     * @return array|null An associative array of the entry, or null if not found.
     */

    public function getEntry($id)
    {
        $entry = Craft::$app->getDb()->createCommand(
            'SELECT * FROM {{%ellinika_db}} WHERE id=:id'
        )->bindValue(':id', $id)->queryOne();

        return $entry;
    }

    /**
     * AT THE MOMENT NOT USED
     * 
     * Inserts a new entry into the database with the provided data.
     * 
     * @param array $data The data for the new entry, including entry_id, text, and url.
     * @return bool True if the entry was successfully inserted, false otherwise.
     */
    public function setEntry($data)
    {
        $db = Craft::$app->getDb();

        $result = $db->createCommand()->insert('{{%ellinika_db}}', [
            'entry_id' => $data['entry_id'],
            'text' => $data['text'],
            'url' => $data['url'],
        ])->execute();

        return $result;
    }

    /**
     * Retrieves all entries from the database.
     * 
     * @return array An array of all entries in the database.
     */
    public function getAllEntries()
    {
        $entries = Craft::$app->getDb()->createCommand(
            'SELECT * FROM {{%ellinika_db}}'
        )->queryAll();

        return $entries;
    }

    /**
     * Renders the index page with a table displaying all entries.
     * It dynamically provides variable representation for rows and columns,
     * reflecting any additions or deletions of rows/columns.
     * 
     * @return mixed The rendered template of the index page.
     */
    public function actionIndex()
    {
        $entries = $this->getAllEntries();
        $columns = !empty($entries) ? array_keys($entries[0]) : [];
    
        return $this->renderTemplate('ellinika/index', [
            'entries' => $entries,
            'columns' => $columns
        ]);
    }

    /**
     * Deletes an entry from the database based on the provided ID and refreshes the index page.
     * 
     * @param int $id The ID of the entry to delete.
     * @throws NotFoundHttpException If the entry is not found.
     * @return mixed The updated index page without the deleted entry.
     */
    public function actionDeleteEntry($id)
    {
        $affectedRows = Craft::$app->getDb()->createCommand()
            ->delete('{{%ellinika_db}}', ['id' => $id])
            ->execute();
    
        if ($affectedRows) {
            $entries = Craft::$app->getDb()->createCommand('SELECT * FROM {{%ellinika_db}}')->queryAll();
            $columns = !empty($entries) ? array_keys($entries[0]) : [];
            return $this->renderTemplate('ellinika/index', ['entries' => $entries, 'columns' => $columns]);
        } else {
            throw new NotFoundHttpException('The requested entry does not exist or could not be deleted.');
        }
    }

    public static function isInTable(int $entryId, int $siteId): bool
    {
        {
            $exists = (new Query())
                ->from('{{%ellinika_db}}')
                ->where([
                    'entry_id' => $entryId,
                    'language_id' => $siteId,
                ])
                ->exists();
            return $exists;
        }
    }

    public static function getLastUpdate($id): string
    {
        return Craft::$app ->getDb()->createCommand(
            'SELECT crested_at FROM {{%ellinika_db}} WHERE id =: id'
        )->bindValue(':id', $id)->queryOne();
    }
}
