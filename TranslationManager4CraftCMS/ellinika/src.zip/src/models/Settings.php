<?php

namespace pse\craftellinika\models;

use Craft;
use craft\base\Model;

/**
 * Ellinika settings
 */
class Settings extends Model
{
}
